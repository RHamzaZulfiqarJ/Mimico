"use client";

import { useEffect, useMemo, useState } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";

export default function CursorTracker() {
    const mouseX = useMotionValue(-100);
    const mouseY = useMotionValue(-100);

    const smoothX = useSpring(mouseX, {
        stiffness: 260,
        damping: 24,
        mass: 0.5,
    });

    const smoothY = useSpring(mouseY, {
        stiffness: 260,
        damping: 24,
        mass: 0.5,
    });

    const glowX = useSpring(mouseX, {
        stiffness: 90,
        damping: 22,
        mass: 0.8,
    });

    const glowY = useSpring(mouseY, {
        stiffness: 90,
        damping: 22,
        mass: 0.8,
    });

    const [enabled, setEnabled] = useState(false);
    const [pressed, setPressed] = useState(false);

    const particles = useMemo(
        () =>
            Array.from({ length: 6 }, (_, index) => ({
                id: index,
                size: 5 + index,
                delay: index * 0.045,
                opacity: 0.18 + index * 0.05,
            })),
        [],
    );

    useEffect(() => {
        const finePointer = window.matchMedia("(pointer: fine)").matches;
        setEnabled(finePointer);

        if (!finePointer) return;

        const handleMove = (event: MouseEvent) => {
            mouseX.set(event.clientX);
            mouseY.set(event.clientY);
        };

        const handleDown = () => setPressed(true);
        const handleUp = () => setPressed(false);

        window.addEventListener("mousemove", handleMove);
        window.addEventListener("mousedown", handleDown);
        window.addEventListener("mouseup", handleUp);

        return () => {
            window.removeEventListener("mousemove", handleMove);
            window.removeEventListener("mousedown", handleDown);
            window.removeEventListener("mouseup", handleUp);
        };
    }, [mouseX, mouseY]);

    if (!enabled) return null;

    return (
        <>
            <style jsx global>{`
                .mimico-cursor-orb,
                .mimico-cursor-ring,
                .mimico-cursor-dot,
                .mimico-cursor-particle {
                    border-radius: 9999px !important;
                }

                .mimico-cursor-orb {
                    background:
                        radial-gradient(circle at 30% 30%, rgba(255, 255, 255, 0.95), transparent 22%),
                        radial-gradient(circle at 60% 45%, rgba(0, 229, 255, 0.55), transparent 34%),
                        radial-gradient(circle at 40% 70%, rgba(217, 70, 239, 0.42), transparent 42%),
                        radial-gradient(circle at 70% 70%, rgba(57, 255, 20, 0.35), transparent 45%);
                    filter: blur(16px);
                }

                .mimico-cursor-ring {
                    background: transparent;
                    border: 1px solid var(--retro-cyan);
                    box-shadow:
                        0 0 12px rgba(0, 229, 255, 0.15),
                        0 0 24px rgba(217, 70, 239, 0.08);
                }

                .mimico-cursor-dot {
                    background: var(--retro-cyan);
                    box-shadow: 0 0 10px var(--retro-cyan);
                }

                .mimico-cursor-particle {
                    background: var(--retro-cyan);
                    box-shadow: 0 0 8px var(--retro-cyan);
                }
            `}</style>

            <motion.div
                className="mimico-cursor-orb pointer-events-none fixed left-0 top-0 z-[9996] hidden h-24 w-24 -translate-x-1/2 -translate-y-1/2 opacity-30 mix-blend-screen md:block"
                style={{
                    x: glowX,
                    y: glowY,
                    scale: pressed ? 0.72 : 1,
                }}
            />

            {particles.map((particle) => (
                <motion.div
                    key={particle.id}
                    className="mimico-cursor-particle pointer-events-none fixed left-0 top-0 z-[9997] hidden -translate-x-1/2 -translate-y-1/2 md:block"
                    style={{
                        x: smoothX,
                        y: smoothY,
                        width: particle.size * 0.5,
                        height: particle.size * 0.5,
                        opacity: particle.opacity * 0.5,
                    }}
                    animate={{
                        scale: pressed ? [1, 1.4, 0.5] : [0.9, 1.1, 0.9],
                    }}
                    transition={{
                        duration: 2,
                        repeat: Infinity,
                        delay: particle.delay,
                        ease: "linear",
                    }}
                />
            ))}

            <motion.div
                className="mimico-cursor-ring pointer-events-none fixed left-0 top-0 z-[9998] hidden h-7 w-7 -translate-x-1/2 -translate-y-1/2 md:block"
                style={{
                    x: smoothX,
                    y: smoothY,
                }}
                animate={{
                    scale: pressed ? 0.85 : 1,
                }}
                transition={{
                    scale: {
                        duration: 0.12,
                        ease: "easeOut",
                    },
                }}
            />

            <motion.div
                className="mimico-cursor-dot pointer-events-none fixed left-0 top-0 z-[9999] hidden h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 md:block"
                style={{
                    x: mouseX,
                    y: mouseY,
                }}
                animate={{
                    scale: pressed ? 1.5 : 1,
                }}
                transition={{
                    duration: 0.1,
                    ease: "easeOut",
                }}
            />
        </>
    );
}
