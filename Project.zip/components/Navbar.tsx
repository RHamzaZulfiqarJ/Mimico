"use client";

import { useEffect, useMemo, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import {
    Bell,
    CalendarClock,
    ChevronDown,
    Command,
    LayoutDashboard,
    Menu,
    MessageCircle,
    Search,
    Sparkles,
    X,
    Zap,
} from "lucide-react";
import { BsTwitterX } from "react-icons/bs";
import { SiMastodon, SiThreads } from "react-icons/si";

type User = {
    firstName: string;
    lastName: string;
    email?: string;
};

const mobileLinks = [
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard, code: "SYS" },
    { href: "/publishing", label: "Publishing", icon: CalendarClock, code: "PUB" },
    { href: "/twitter", label: "Twitter / X", icon: BsTwitterX, code: "X01" },
    { href: "/mastodon", label: "Mastodon", icon: SiMastodon, code: "MST" },
    { href: "/threads", label: "Threads", icon: SiThreads, code: "THR" },
    { href: "/whatsapp", label: "WhatsApp", icon: MessageCircle, code: "WAP" },
];

const pageLabels: Record<string, string> = {
    dashboard: "Dashboard",
    publishing: "Publishing",
    twitter: "Twitter / X",
    mastodon: "Mastodon",
    threads: "Threads",
    whatsapp: "WhatsApp",
    analytics: "Analytics",
};

export default function Navbar() {
    const router = useRouter();
    const pathname = usePathname();
    const [user, setUser] = useState<User | null>(null);
    const [loading, setLoading] = useState(true);
    const [mobileOpen, setMobileOpen] = useState(false);
    const [searchValue, setSearchValue] = useState("");

    const pageName = useMemo(() => {
        const key = pathname.split("/").filter(Boolean)[0] || "dashboard";
        return pageLabels[key] || "Workspace";
    }, [pathname]);

    const initials = useMemo(() => {
        if (!user) return "HM"; // Fallback initials

        const first = user.firstName?.[0] || "";
        const last = user.lastName?.[0] || "";

        return `${first}${last}`.toUpperCase() || "HM";
    }, [user]);

    useEffect(() => {
        async function loadUser() {
            try {
                const res = await fetch("/api/auth/user");

                if (!res.ok) {
                    router.push("/login");
                    return;
                }

                const data = await res.json();
                setUser(data.user);
            } catch (error) {
                console.error("Failed to fetch user session:", error);
            } finally {
                setLoading(false);
            }
        }

        loadUser();
    }, [router]);

    const handleSearchSubmit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        const value = searchValue.trim();
        if (!value) return;

        router.push(`/publishing?search=${encodeURIComponent(value)}`);
    };

    return (
        <header className="sticky top-0 z-40 border-b-2 border-[var(--retro-line)] bg-white/90 backdrop-blur-md">
            <div className="flex min-h-20 items-center justify-between gap-4 px-4 md:px-6 lg:px-8">
                {/* Left Section: Brand & Page Context */}
                <div className="flex min-w-0 items-center gap-3">
                    <button
                        onClick={() => setMobileOpen((prev) => !prev)}
                        className="flex h-11 w-11 shrink-0 items-center justify-center border-2 border-[var(--retro-line)] bg-[var(--retro-yellow)] shadow-[3px_3px_0px_0px_var(--retro-line)] transition-transform active:translate-x-0.5 active:translate-y-0.5 active:shadow-[1px_1px_0px_0px_var(--retro-line)] md:hidden"
                        aria-label="Toggle menu"
                    >
                        {mobileOpen ? (
                            <X className="h-5 w-5 text-[var(--retro-ink)]" />
                        ) : (
                            <Menu className="h-5 w-5 text-[var(--retro-ink)]" />
                        )}
                    </button>

                    <div className="hidden h-11 w-11 shrink-0 items-center justify-center border-2 border-[var(--retro-line)] bg-[var(--retro-cyan)] shadow-[3px_3px_0px_0px_var(--retro-line)] sm:flex">
                        <Command className="h-5 w-5 text-[var(--retro-ink)]" />
                    </div>

                    <div className="min-w-0">
                        <div className="flex items-center gap-2 leading-none mb-0.5">
                            <span className="font-mono text-[9px] font-black uppercase tracking-[0.2em] text-[var(--retro-muted)]">
                                Current Module
                            </span>
                            <span className="hidden border-2 border-[var(--retro-line)] bg-[var(--retro-lime)] px-1.5 py-0.5 font-mono text-[8px] font-black uppercase tracking-[0.1em] text-[var(--retro-ink)] sm:inline-flex">
                                Active
                            </span>
                        </div>
                        <h1 className="truncate text-xl font-black tracking-tight text-[var(--retro-ink)] uppercase md:text-2xl">
                            {pageName}
                        </h1>
                    </div>
                </div>

                {/* Middle Section: Command Search Bar */}
                <form onSubmit={handleSearchSubmit} className="hidden flex-1 justify-center lg:flex">
                    <div className="relative w-full max-w-xl">
                        <div className="pointer-events-none absolute left-0 top-0 flex h-full w-12 items-center justify-center border-r-2 border-[var(--retro-line)] bg-[var(--retro-bg-soft)]">
                            <Search className="h-4 w-4 text-[var(--retro-ink)]" />
                        </div>

                        <input
                            type="text"
                            value={searchValue}
                            onChange={(event) => setSearchValue(event.target.value)}
                            placeholder="Search posts, platforms, accounts..."
                            className="retro-input h-12 w-full border-2 border-[var(--retro-line)] pl-16 pr-32 font-mono text-xs font-bold tracking-wide placeholder:text-slate-400 focus:outline-none focus:bg-[var(--retro-bg-soft)] shadow-[3px_3px_0px_0px_var(--retro-line)]"
                        />

                        <div className="pointer-events-none absolute right-2 top-1/2 hidden -translate-y-1/2 items-center gap-1 border-2 border-[var(--retro-line)] bg-[var(--retro-yellow)] px-2 py-1 font-mono text-[9px] font-black uppercase tracking-[0.1em] text-[var(--retro-ink)] xl:flex">
                            <Command className="h-3 w-3" />
                            Search
                        </div>
                    </div>
                </form>

                {/* Right Section: System Actions & Profile */}
                <div className="flex items-center gap-3 shrink-0">
                    <button
                        className="relative hidden h-11 w-11 items-center justify-center border-2 border-[var(--retro-line)] bg-white shadow-[3px_3px_0px_0px_var(--retro-line)] transition-all duration-150 hover:-translate-x-0.5 hover:-translate-y-0.5 hover:bg-[var(--retro-yellow)] hover:shadow-[5px_5px_0px_0px_var(--retro-line)] sm:flex"
                        aria-label="Notifications"
                    >
                        <Bell className="h-5 w-5 text-[var(--retro-ink)]" />
                        <span className="absolute -right-1 -top-1 h-3.5 w-3.5 border-2 border-[var(--retro-line)] bg-[var(--retro-magenta)] shadow-[1px_1px_0px_0px_var(--retro-line)]" />
                    </button>

                    <div className="hidden h-11 items-center gap-2 border-2 border-[var(--retro-line)] bg-[var(--retro-mint)] px-3 shadow-[3px_3px_0px_0px_var(--retro-line)] xl:flex">
                        <Zap className="h-4 w-4 text-[var(--retro-ink)] animate-pulse" />
                        <span className="font-mono text-[9px] font-black uppercase tracking-[0.15em] text-[var(--retro-ink)]">
                            Synced
                        </span>
                    </div>

                    <button className="group flex h-12 items-center gap-3 border-2 border-[var(--retro-line)] bg-white px-2.5 shadow-[4px_4px_0px_0px_var(--retro-line)] transition-all duration-150 hover:-translate-x-0.5 hover:-translate-y-0.5 hover:bg-[var(--retro-pink-soft)] hover:shadow-[6px_6px_0px_0px_var(--retro-line)]">
                        <div className="flex h-8 w-8 items-center justify-center border-2 border-[var(--retro-line)] bg-[var(--retro-cyan)] font-mono text-xs font-black text-[var(--retro-ink)] shadow-[1px_1px_0px_0px_var(--retro-line)]">
                            {initials}
                        </div>

                        <div className="hidden min-w-0 text-left md:block">
                            <p className="max-w-36 truncate text-sm font-black tracking-tight text-[var(--retro-ink)] uppercase leading-none mb-0.5">
                                {loading
                                    ? "Loading..."
                                    : user
                                      ? `${user.firstName} ${user.lastName}`
                                      : "Account Manager"}
                            </p>
                            <p className="font-mono text-[9px] font-black uppercase tracking-[0.15em] text-[var(--retro-muted)]">
                                Admin Manager
                            </p>
                        </div>

                        <ChevronDown className="hidden h-4 w-4 text-[var(--retro-ink)] transition-transform duration-150 group-hover:translate-y-0.5 md:block" />
                    </button>
                </div>
            </div>

            {/* Mobile Navigation Drawer Dropdown */}
            {mobileOpen && (
                <div className="border-t-2 border-[var(--retro-line)] bg-white p-4 shadow-[inset_0_2px_4px_rgba(0,0,0,0.05)] md:hidden">
                    <form onSubmit={handleSearchSubmit} className="mb-4">
                        <div className="relative">
                            <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--retro-ink)]" />
                            <input
                                type="text"
                                value={searchValue}
                                onChange={(event) => setSearchValue(event.target.value)}
                                placeholder="Search everything..."
                                className="retro-input h-11 w-full border-2 border-[var(--retro-line)] pl-11 pr-4 font-mono text-xs font-bold shadow-[2px_2px_0px_0px_var(--retro-line)] focus:outline-none"
                            />
                        </div>
                    </form>

                    <div className="grid gap-3">
                        {mobileLinks.map((item) => {
                            const Icon = item.icon;
                            const isActive = pathname === item.href || pathname.startsWith(`${item.href}/`);

                            return (
                                <button
                                    key={item.href}
                                    onClick={() => {
                                        router.push(item.href);
                                        setMobileOpen(false);
                                    }}
                                    className={`flex items-center gap-3 border-2 border-[var(--retro-line)] px-3 py-2.5 text-left shadow-[3px_3px_0px_0px_var(--retro-line)] transition-all active:translate-x-0.5 active:translate-y-0.5 active:shadow-[1px_1px_0px_0px_var(--retro-line)] ${
                                        isActive ? "bg-[var(--retro-cyan)]" : "bg-white"
                                    }`}
                                >
                                    <span className="flex h-8 w-8 shrink-0 items-center justify-center border-2 border-[var(--retro-line)] bg-[var(--retro-yellow)] shadow-[1px_1px_0px_0px_var(--retro-line)]">
                                        <Icon className="h-4 w-4 text-[var(--retro-ink)]" />
                                    </span>

                                    <span className="flex-1 text-xs font-black uppercase tracking-wide text-[var(--retro-ink)]">
                                        {item.label}
                                    </span>

                                    <span className="font-mono text-[9px] font-black uppercase tracking-[0.1em] text-[var(--retro-muted)]">
                                        /{item.code}
                                    </span>
                                </button>
                            );
                        })}
                    </div>

                    <div className="mt-4 flex items-center gap-2 border-2 border-[var(--retro-line)] bg-[var(--retro-mint)] px-3 py-2.5 shadow-[3px_3px_0px_0px_var(--retro-line)]">
                        <Sparkles className="h-4 w-4 text-[var(--retro-ink)]" />
                        <span className="font-mono text-[9px] font-black uppercase tracking-[0.15em] text-[var(--retro-ink)]">
                            RetroUI mobile console
                        </span>
                    </div>
                </div>
            )}
        </header>
    );
}
