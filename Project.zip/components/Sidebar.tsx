"use client";

import { motion } from "framer-motion";
import { LayoutDashboard, CalendarClock, BarChart3, Share2, LogOut, MessageCircle, Sparkles, Zap } from "lucide-react";
import { BsTwitterX } from "react-icons/bs";
import { SiMastodon, SiThreads } from "react-icons/si";
import { usePathname, useRouter } from "next/navigation";

const navItems = [
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard, code: "SYS" },
    { href: "/publishing", label: "Publishing", icon: CalendarClock, code: "PUB" },
    { href: "/twitter", label: "Twitter / X", icon: BsTwitterX, code: "X01" },
    { href: "/mastodon", label: "Mastodon", icon: SiMastodon, code: "MST" },
    { href: "/threads", label: "Threads", icon: SiThreads, code: "THR" },
    { href: "/whatsapp", label: "WhatsApp", icon: MessageCircle, code: "WAP" },
    { href: "/analytics", label: "Analytics", icon: BarChart3, code: "ANA" },
];

export default function Sidebar() {
    const pathname = usePathname();
    const router = useRouter();

    const handleLogout = async () => {
        await fetch("/api/auth/logout", {
            method: "POST",
        });

        window.location.href = "/login";
    };

    return (
        <motion.aside
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
            className="sticky top-0 z-50 hidden h-screen w-64 shrink-0 border-r border-[var(--retro-line)] bg-[#fafafa] md:flex md:flex-col"
        >
            <div className="border-b border-[var(--retro-line)] p-4 bg-white">
                <button onClick={() => router.push("/dashboard")} className="group flex w-full items-center gap-3">
                    <div className="flex h-9 w-9 items-center justify-center border border-[var(--retro-line)] bg-white shadow-[0_1px_2px_rgba(0,0,0,0.02)] transition-colors group-hover:bg-[var(--retro-bg-soft)]">
                        <Share2 className="h-4 w-4 text-[var(--retro-cyan)]" />
                    </div>

                    <div className="text-left">
                        <div className="text-xs font-semibold text-[var(--retro-muted)] leading-none mb-0.5">
                            Control Panel
                        </div>
                        <div className="text-sm font-bold tracking-tight text-[var(--retro-ink)] uppercase">MIMICO</div>
                    </div>
                </button>
            </div>

            <div className="border-b border-[var(--retro-line)] px-4 py-2.5 bg-white">
                <div className="flex items-center justify-between border border-[var(--retro-line)] bg-[var(--retro-bg-soft)] px-2.5 py-1.5 shadow-[inset_0_1px_1px_rgba(0,0,0,0.01)]">
                    <div className="flex items-center gap-2">
                        <Sparkles className="h-3.5 w-3.5 text-[var(--retro-cyan)]" />
                        <span className="text-[11px] font-medium text-[var(--retro-ink-soft)]">Workspace</span>
                    </div>
                    <span className="bg-[var(--retro-mint)] border border-emerald-200 text-emerald-700 px-1.5 py-0.5 text-[9px] font-medium leading-none">
                        LIVE
                    </span>
                </div>
            </div>

            <nav className="custom-scrollbar flex-1 space-y-1 overflow-y-auto p-3">
                {navItems.map((item, index) => {
                    const isActive = pathname === item.href || pathname.startsWith(`${item.href}/`);
                    const Icon = item.icon;

                    return (
                        <button
                            key={item.href}
                            onClick={() => router.push(item.href)}
                            className={`group relative flex w-full items-center justify-between border px-3 py-2 text-left transition-all duration-150 ${
                                isActive
                                    ? "border-[var(--retro-line)] bg-white shadow-[0_1px_3px_rgba(0,0,0,0.04)]"
                                    : "border-transparent bg-transparent hover:bg-[var(--retro-bg-soft)]"
                            }`}
                        >
                            <div className="flex items-center gap-3 min-w-0">
                                <Icon
                                    className={`h-4 w-4 shrink-0 transition-colors ${
                                        isActive
                                            ? "text-[var(--retro-cyan)]"
                                            : "text-[var(--retro-muted)] group-hover:text-[var(--retro-ink)]"
                                    }`}
                                />
                                <span
                                    className={`truncate text-sm transition-colors ${
                                        isActive
                                            ? "font-medium text-[var(--retro-ink)]"
                                            : "font-normal text-[var(--retro-ink-soft)] group-hover:text-[var(--retro-ink)]"
                                    }`}
                                >
                                    {item.label}
                                </span>
                            </div>

                            {isActive ? (
                                <motion.span
                                    layoutId="sidebar-active-marker"
                                    className="h-1.5 w-1.5 bg-[var(--retro-cyan)]"
                                />
                            ) : (
                                <span className="font-mono text-[9px] font-medium tracking-wide text-[var(--retro-muted)] opacity-0 group-hover:opacity-100 transition-opacity">
                                    {item.code}
                                </span>
                            )}
                        </button>
                    );
                })}
            </nav>

            <div className="border-t border-[var(--retro-line)] bg-white p-3 space-y-3">
                <div className="border border-[var(--retro-line)] bg-[var(--retro-bg-soft)] p-2.5">
                    <div className="mb-1.5 flex items-center gap-2">
                        <Zap className="h-3.5 w-3.5 text-[var(--retro-muted)]" />
                        <span className="text-[11px] font-medium text-[var(--retro-muted)]">System Status</span>
                    </div>
                    <div className="flex items-center justify-between">
                        <span className="text-xs text-[var(--retro-ink-soft)]">Operational</span>
                        <span className="h-1.5 w-1.5 bg-[var(--retro-lime)]" />
                    </div>
                </div>

                <button
                    onClick={handleLogout}
                    className="retro-button-secondary flex w-full items-center justify-center gap-2 px-3 py-2 text-xs"
                >
                    <LogOut className="h-3.5 w-3.5 text-[var(--retro-muted)]" />
                    <span>Logout</span>
                </button>
            </div>
        </motion.aside>
    );
}
