"use client";

import { motion } from "framer-motion";
import { CheckCircle2, ExternalLink, PlugZap, Trash2, Wifi } from "lucide-react";
import { PLATFORMS } from "@/libs/platform";

interface AccountCardProps {
    platform: string;
    username: string;
    connectedAt?: string;
    loadingDelete?: boolean;
    onDisconnect?: () => void;
}

const platformAccent: Record<string, string> = {
    twitter: "from-[#171422] to-[#6c5ce7]",
    mastodon: "from-[#6364ff] to-[#00c2a8]",
    threads: "from-[#ff4ecd] to-[#6c5ce7]",
};

export default function StatCard({ platform, username, connectedAt, loadingDelete, onDisconnect }: AccountCardProps) {
    const platformInfo = PLATFORMS[platform as keyof typeof PLATFORMS];
    const Icon = platformInfo?.icon;
    const accent = platformAccent[platform] || "from-[#ffcc33] to-[#ff4ecd]";

    return (
        <motion.div
            initial={{ y: 18, opacity: 0, scale: 0.98 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            whileHover={{ y: -6, rotate: -0.4 }}
            transition={{ duration: 0.28, ease: "easeOut" }}
            className="group relative min-h-[18rem] overflow-hidden rounded-[1.65rem] border border-[#eadfca] bg-white p-4 shadow-[0_18px_42px_rgba(23,20,34,0.08)] transition-all duration-300 hover:border-[#6c5ce7]/35 hover:shadow-[6px_6px_0_rgba(255,78,205,0.18),-6px_-6px_0_rgba(0,194,168,0.14),0_24px_54px_rgba(23,20,34,0.12)] dark:border-[#302941] dark:bg-[#171422] dark:hover:border-[#9b8cff]/40 dark:hover:shadow-[6px_6px_0_rgba(255,112,220,0.16),-6px_-6px_0_rgba(53,242,213,0.12),0_24px_54px_rgba(0,0,0,0.36)]"
        >
            <div className={`absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r ${accent}`} />
            <div
                className={`absolute -right-16 -top-16 h-44 w-44 rounded-full bg-gradient-to-br ${accent} opacity-16 blur-3xl transition-opacity duration-300 group-hover:opacity-26`}
            />
            <div className="absolute bottom-4 right-4 h-16 w-16 rounded-[1.3rem] border border-[#eadfca] bg-[#fff7df]/70 shadow-[4px_-4px_0_rgba(108,92,231,0.12)] dark:border-[#302941] dark:bg-[#211c31]/70 dark:shadow-[4px_-4px_0_rgba(155,140,255,0.12)]" />

            <div className="relative z-10 flex h-full flex-col">
                <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                        <div
                            className={`flex h-12 w-12 items-center justify-center rounded-[1.1rem] bg-gradient-to-br ${accent} text-white shadow-[0_14px_28px_rgba(108,92,231,0.22)]`}
                        >
                            {Icon ? <Icon className="h-5 w-5" /> : <PlugZap className="h-5 w-5" />}
                        </div>

                        <div>
                            <p className="text-[10px] font-black uppercase tracking-[0.22em] text-[#9a93a8] dark:text-[#7e7891]">
                                Connected
                            </p>
                            <h3 className="mt-1 text-sm font-black text-[#171422] dark:text-[#fffaf0]">
                                {platformInfo?.name || platform}
                            </h3>
                        </div>
                    </div>

                    <div className="flex h-10 w-10 items-center justify-center rounded-[1rem] border border-[#bff4e8] bg-[#dcfff6] text-[#00866d] dark:border-[#235a4f] dark:bg-[#4df5c8]/12 dark:text-[#8ffff0]">
                        <CheckCircle2 className="h-5 w-5" />
                    </div>
                </div>

                <div className="mt-7 rounded-[1.35rem] border border-[#eadfca] bg-[#fffaf0] p-4 shadow-inner dark:border-[#302941] dark:bg-[#211c31]">
                    <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.2em] text-[#706a7c] dark:text-[#b8b1c9]">
                        <Wifi className="h-3.5 w-3.5 text-[#00c2a8] dark:text-[#35f2d5]" />
                        Account Handle
                    </div>

                    <p className="mt-2 truncate text-2xl font-black tracking-tight text-[#171422] dark:text-[#fffaf0]">
                        @{username}
                    </p>

                    {connectedAt && (
                        <p className="mt-2 text-xs font-bold text-[#9a93a8] dark:text-[#7e7891]">
                            Connected on {new Date(connectedAt).toLocaleDateString()}
                        </p>
                    )}
                </div>

                <div className="mt-auto grid grid-cols-[1fr_auto] gap-2 pt-4">
                    <button
                        type="button"
                        onClick={onDisconnect}
                        disabled={loadingDelete}
                        className="glitch-hover flex items-center justify-center gap-2 rounded-[1.15rem] border border-[#ffd0da] bg-[#ffe2e8] px-4 py-3 text-sm font-black text-[#c91f42] shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:bg-[#ffd7e0] disabled:cursor-not-allowed disabled:opacity-60 dark:border-[#5a2634] dark:bg-[#ff6b86]/12 dark:text-[#ffadbd] dark:hover:bg-[#ff6b86]/18"
                    >
                        <Trash2 className="h-4 w-4" />
                        {loadingDelete ? "Disconnecting..." : "Disconnect"}
                    </button>

                    <button
                        type="button"
                        className="glitch-hover flex h-12 w-12 items-center justify-center rounded-[1.15rem] border border-[#eadfca] bg-white text-[#6c5ce7] shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:border-[#6c5ce7]/35 hover:bg-[#eeeaff] dark:border-[#302941] dark:bg-[#171422] dark:text-[#d9d3ff] dark:hover:border-[#9b8cff]/40 dark:hover:bg-[#211c31]"
                    >
                        <ExternalLink className="h-4 w-4" />
                    </button>
                </div>
            </div>
        </motion.div>
    );
}
