import nodemailer from "nodemailer";

type PasswordResetEmailInput = {
    to: string;
    firstName: string;
    resetUrl: string;
};

export function isMailConfigured() {
    return Boolean(
        process.env.SMTP_HOST &&
        process.env.SMTP_PORT &&
        process.env.SMTP_USER &&
        process.env.SMTP_PASS &&
        process.env.SMTP_FROM,
    );
}

export async function sendPasswordResetEmail({ to, firstName, resetUrl }: PasswordResetEmailInput) {
    if (!isMailConfigured()) {
        throw new Error("SMTP is not configured");
    }

    const port = Number(process.env.SMTP_PORT);

    const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port,
        secure: port === 465,
        auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_PASS,
        },
    });

    await transporter.verify();

    await transporter.sendMail({
        from: process.env.SMTP_FROM,
        to,
        subject: "Reset your MIMICO password",
        text: `Hi ${firstName},

Use this link to reset your password:

${resetUrl}

This link expires in 15 minutes.

If you did not request this, ignore this email.`,
        html: `
      <div style="background:#0d0e12;padding:32px;font-family:Inter,Arial,sans-serif;color:#f7f8f8">
        <div style="max-width:520px;margin:0 auto;background:#15161d;border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:28px">
          <h1 style="margin:0 0 12px;color:#fff;font-size:22px">Reset your password</h1>
          <p style="margin:0 0 20px;color:#b4bcd0;font-size:14px;line-height:1.6">Hi ${firstName}, use the button below to reset your MIMICO password. This link expires in 15 minutes.</p>
          <a href="${resetUrl}" style="display:inline-block;background:#5e6ad2;color:#fff;text-decoration:none;padding:12px 16px;border-radius:6px;font-size:14px;font-weight:600">Reset Password</a>
          <p style="margin:24px 0 0;color:#6c7283;font-size:12px;line-height:1.6">If the button does not work, copy this link:</p>
          <p style="word-break:break-all;color:#b4bcd0;font-size:12px;line-height:1.6">${resetUrl}</p>
          <p style="margin:24px 0 0;color:#6c7283;font-size:12px">If you did not request this, ignore this email.</p>
        </div>
      </div>
    `,
    });

    return {
        sent: true,
    };
}
