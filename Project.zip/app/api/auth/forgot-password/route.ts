export const runtime = "nodejs";

import crypto from "crypto";
import { NextResponse } from "next/server";
import { prisma } from "@/libs/prisma";
import { forgotPasswordSchema } from "@/libs/validation";
import { sendPasswordResetEmail } from "@/libs/mail";

const genericMessage = "If an account exists with this email, a password reset link has been sent.";

function hashToken(token: string) {
    return crypto.createHash("sha256").update(token).digest("hex");
}

export async function POST(req: Request) {
    try {
        const body = await req.json();
        const parsed = forgotPasswordSchema.safeParse(body);

        if (!parsed.success) {
            return NextResponse.json({ message: "Enter a valid email address" }, { status: 400 });
        }

        const email = parsed.data.email.toLowerCase();

        const user = await prisma.user.findUnique({
            where: { email },
            select: {
                id: true,
                firstName: true,
                email: true,
                passwordResetRequestedAt: true,
            },
        });

        let devResetUrl: string | undefined;

        if (user) {
            const isProduction = process.env.NODE_ENV === "production";
            const recentlyRequested =
                isProduction &&
                user.passwordResetRequestedAt &&
                Date.now() - user.passwordResetRequestedAt.getTime() < 60 * 1000;

            if (!recentlyRequested) {
                const token = crypto.randomBytes(32).toString("hex");
                const tokenHash = hashToken(token);
                const expiresAt = new Date(Date.now() + 15 * 60 * 1000);
                const appUrl = process.env.NEXT_PUBLIC_APP_URL || new URL(req.url).origin;
                const resetUrl = `${appUrl}/reset-password/${token}`;

                await prisma.user.update({
                    where: { id: user.id },
                    data: {
                        passwordResetToken: tokenHash,
                        passwordResetTokenExpiresAt: expiresAt,
                        passwordResetRequestedAt: new Date(),
                    },
                });

                try {
                    await sendPasswordResetEmail({
                        to: user.email,
                        firstName: user.firstName,
                        resetUrl,
                    });
                } catch (error) {
                    console.error("PASSWORD RESET EMAIL ERROR:", error);

                    if (!isProduction) {
                        return NextResponse.json(
                            {
                                message: "Email sending failed",
                                error: error instanceof Error ? error.message : "Unknown SMTP error",
                                devResetUrl: resetUrl,
                            },
                            { status: 500 },
                        );
                    }

                    return NextResponse.json({ message: "Email sending failed. Try again later." }, { status: 500 });
                }
            }
        }

        return NextResponse.json(
            {
                message: genericMessage,
                devResetUrl,
            },
            { status: 200 },
        );
    } catch (error) {
        console.error("FORGOT PASSWORD ERROR:", error);

        return NextResponse.json({ message: "Password reset request failed" }, { status: 500 });
    }
}
