import type { Metadata } from "next";
import "./globals.css";
import CursorTracker from "@/components/CursorTracker";

export const metadata: Metadata = {
    title: "Account Manager",
    description: "Linear-inspired professional social account management platform",
};

export default function RootLayout({
    children,
}: Readonly<{
    children: React.ReactNode;
}>) {
    return (
        <html lang="en" suppressHydrationWarning>
            <body className="min-h-screen overflow-x-hidden bg-[var(--retro-bg)] text-[var(--retro-ink)] antialiased selection:bg-[var(--retro-cyan)]/20 selection:text-[var(--retro-cyan)]">
                <div className="fixed inset-0 -z-20 bg-[var(--retro-bg)]" />
                <div className="fixed inset-0 -z-10 pointer-events-none opacity-40 retro-grid" />
                <div className="fixed left-0 right-0 top-0 -z-10 h-[500px] bg-gradient-to-b from-[rgba(94,106,210,0.06)] via-transparent to-transparent pointer-events-none" />
                <div className="fixed left-[10%] top-[-10%] -z-10 h-[350px] w-[600px] bg-[rgba(94,106,210,0.03)] blur-[120px] pointer-events-none rounded-full" />
                <div className="fixed right-[5%] top-[15%] -z-10 h-[250px] w-[400px] bg-[rgba(168,85,247,0.02)] blur-[100px] pointer-events-none rounded-full" />
                <CursorTracker />
                {children}
            </body>
        </html>
    );
}
