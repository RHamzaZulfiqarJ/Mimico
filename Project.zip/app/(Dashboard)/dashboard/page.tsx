"use client";

import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { useRouter } from "next/navigation";
import {
    AlertTriangle,
    BarChart3,
    CalendarClock,
    CheckCircle2,
    Clock,
    FileText,
    Loader2,
    MessageCircle,
    RefreshCw,
    Send,
    Share2,
    Sparkles,
    TrendingUp,
    Users,
    Zap,
    type LucideIcon,
} from "lucide-react";
import {
    ApiClientError,
    whatsappClient,
    type WhatsAppAccount,
    type WhatsAppScheduledMessage,
} from "@/libs/whatsapp/client";

type User = {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
};

type SocialAccount = {
    id: string;
    platform: string;
    accountUsername: string;
    createdAt: string;
};

type SocialPost = {
    id: string;
    content: string;
    scheduledAt: string;
    postedAt: string | null;
    status: string;
    errorMessage?: string | null;
    createdAt: string;
    socialAccount: {
        accountUsername: string;
        platform: string;
    };
};

type WhatsAppSummary = {
    account: WhatsAppAccount;
    contacts: number;
    templates: number;
    approvedTemplates: number;
    queued: number;
    sent: number;
    failed: number;
    recentQueued: WhatsAppScheduledMessage[];
    recentFailed: WhatsAppScheduledMessage[];
};

type Notice = {
    type: "success" | "error";
    message: string;
} | null;

type ActivityItem = {
    id: string;
    title: string;
    subtitle: string;
    status: string;
    time: string;
    type: "social" | "whatsapp";
    isFailed: boolean;
};

const getErrorMessage = (error: unknown) => {
    if (error instanceof ApiClientError) {
        return error.message;
    }

    if (error instanceof Error) {
        return error.message;
    }

    return "Something went wrong";
};

const formatDateTime = (value?: string | null) => {
    if (!value) {
        return "N/A";
    }

    return new Date(value).toLocaleString();
};

const normalizePlatform = (platform: string) => {
    const value = platform.toLowerCase();

    if (value === "twitter") {
        return "Twitter / X";
    }

    if (value === "mastodon") {
        return "Mastodon";
    }

    if (value === "threads") {
        return "Instagram Threads";
    }

    if (value === "whatsapp") {
        return "WhatsApp";
    }

    return platform;
};

const getStatusClass = (status: string) => {
    const value = status.toLowerCase();

    if (value === "posted" || value === "sent") {
        return "bg-[var(--retro-lime)] text-[var(--retro-ink)]";
    }

    if (value === "pending" || value === "queued" || value === "processing") {
        return "bg-[var(--retro-yellow)] text-[var(--retro-ink)]";
    }

    if (value === "failed") {
        return "bg-[#ff4d6d] text-white";
    }

    return "bg-[var(--retro-magenta)] text-white";
};

export default function DashboardPage() {
    const router = useRouter();

    const [user, setUser] = useState<User | null>(null);
    const [socialAccounts, setSocialAccounts] = useState<SocialAccount[]>([]);
    const [socialPosts, setSocialPosts] = useState<SocialPost[]>([]);
    const [whatsAppAccounts, setWhatsAppAccounts] = useState<WhatsAppAccount[]>([]);
    const [whatsAppSummaries, setWhatsAppSummaries] = useState<WhatsAppSummary[]>([]);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [notice, setNotice] = useState<Notice>(null);

    const showNotice = (type: "success" | "error", message: string) => {
        setNotice({ type, message });

        window.setTimeout(() => {
            setNotice(null);
        }, 3500);
    };

    const loadWhatsAppSummaries = async (accounts: WhatsAppAccount[]) => {
        const summaries = await Promise.all(
            accounts.map(async (account) => {
                try {
                    const [contacts, templates, queued, sent, failed] = await Promise.all([
                        whatsappClient.listContacts(account.id, { limit: 1 }),
                        whatsappClient.listTemplates(account.id, { limit: 100 }),
                        whatsappClient.listScheduledMessages(account.id, { limit: 5, status: "QUEUED" }),
                        whatsappClient.listScheduledMessages(account.id, { limit: 1, status: "SENT" }),
                        whatsappClient.listScheduledMessages(account.id, { limit: 5, status: "FAILED" }),
                    ]);

                    const approvedTemplates = templates.items.filter((template) => {
                        return template.status?.toUpperCase() === "APPROVED";
                    }).length;

                    return {
                        account,
                        contacts: contacts.total,
                        templates: templates.total,
                        approvedTemplates,
                        queued: queued.total,
                        sent: sent.total,
                        failed: failed.total,
                        recentQueued: queued.items,
                        recentFailed: failed.items,
                    };
                } catch {
                    return {
                        account,
                        contacts: 0,
                        templates: 0,
                        approvedTemplates: 0,
                        queued: 0,
                        sent: 0,
                        failed: 0,
                        recentQueued: [],
                        recentFailed: [],
                    };
                }
            }),
        );

        return summaries;
    };

    const loadDashboard = async () => {
        try {
            setRefreshing(true);

            const userRes = await fetch("/api/auth/user");

            if (!userRes.ok) {
                router.push("/login");
                return;
            }

            const userData = await userRes.json();
            setUser(userData.user);

            const [accountsRes, postsRes, whatsAppRes] = await Promise.all([
                fetch("/api/accounts"),
                fetch("/api/posts"),
                whatsappClient.listAccounts(),
            ]);

            const accountsData = accountsRes.ok ? await accountsRes.json() : { accounts: [] };
            const postsData = postsRes.ok ? await postsRes.json() : { posts: [] };

            const socialOnly = (accountsData.accounts || []).filter((account: SocialAccount) => {
                const platform = account.platform.toLowerCase();
                return platform === "twitter" || platform === "mastodon" || platform === "threads";
            });

            const whatsAppSummaryData = await loadWhatsAppSummaries(whatsAppRes.accounts);

            setSocialAccounts(socialOnly);
            setSocialPosts(postsData.posts || []);
            setWhatsAppAccounts(whatsAppRes.accounts);
            setWhatsAppSummaries(whatsAppSummaryData);
        } catch (error) {
            showNotice("error", getErrorMessage(error));
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    };

    useEffect(() => {
        loadDashboard();
    }, []);

    const stats = useMemo(() => {
        const twitterAccounts = socialAccounts.filter((account) => {
            return account.platform.toLowerCase() === "twitter";
        }).length;

        const mastodonAccounts = socialAccounts.filter((account) => {
            return account.platform.toLowerCase() === "mastodon";
        }).length;

        const threadsAccounts = socialAccounts.filter((account) => {
            return account.platform.toLowerCase() === "threads";
        }).length;

        const socialPending = socialPosts.filter((post) => post.status === "pending").length;
        const socialProcessing = socialPosts.filter((post) => post.status === "processing").length;
        const socialPosted = socialPosts.filter((post) => post.status === "posted").length;
        const socialFailed = socialPosts.filter((post) => post.status === "failed").length;

        const whatsappContacts = whatsAppSummaries.reduce((total, item) => total + item.contacts, 0);
        const whatsappTemplates = whatsAppSummaries.reduce((total, item) => total + item.templates, 0);
        const approvedTemplates = whatsAppSummaries.reduce((total, item) => total + item.approvedTemplates, 0);
        const whatsappQueued = whatsAppSummaries.reduce((total, item) => total + item.queued, 0);
        const whatsappSent = whatsAppSummaries.reduce((total, item) => total + item.sent, 0);
        const whatsappFailed = whatsAppSummaries.reduce((total, item) => total + item.failed, 0);

        return {
            totalAccounts: socialAccounts.length + whatsAppAccounts.length,
            twitterAccounts,
            mastodonAccounts,
            threadsAccounts,
            whatsAppNumbers: whatsAppAccounts.length,
            whatsappContacts,
            whatsappTemplates,
            approvedTemplates,
            pendingWork: socialPending + socialProcessing + whatsappQueued,
            completedWork: socialPosted + whatsappSent,
            failedWork: socialFailed + whatsappFailed,
            socialPosts: socialPosts.length,
            whatsappMessages: whatsappQueued + whatsappSent + whatsappFailed,
        };
    }, [socialAccounts, socialPosts, whatsAppAccounts, whatsAppSummaries]);

    const activityItems = useMemo<ActivityItem[]>(() => {
        const socialItems: ActivityItem[] = socialPosts.slice(0, 8).map((post) => ({
            id: post.id,
            title: `${normalizePlatform(post.socialAccount.platform)} post`,
            subtitle: post.content,
            status: post.status,
            time: formatDateTime(post.status === "posted" ? post.postedAt : post.scheduledAt),
            type: "social",
            isFailed: post.status === "failed",
        }));

        const whatsAppItems: ActivityItem[] = whatsAppSummaries
            .flatMap((summary) => {
                const queued = summary.recentQueued.map((message) => ({
                    id: message.id,
                    title: "WhatsApp template message",
                    subtitle: `${message.templateName || "Template"} to ${message.recipientPhone}`,
                    status: message.status,
                    time: formatDateTime(message.scheduledAt),
                    type: "whatsapp" as const,
                    isFailed: false,
                }));

                const failed = summary.recentFailed.map((message) => ({
                    id: message.id,
                    title: "WhatsApp failed message",
                    subtitle:
                        message.errorMessage || `${message.templateName || "Template"} to ${message.recipientPhone}`,
                    status: message.status,
                    time: formatDateTime(message.updatedAt),
                    type: "whatsapp" as const,
                    isFailed: true,
                }));

                return [...failed, ...queued];
            })
            .slice(0, 8);

        return [...whatsAppItems, ...socialItems].slice(0, 10);
    }, [socialPosts, whatsAppSummaries]);

    const readiness = useMemo(() => {
        return [
            {
                title: "Connected channels",
                text:
                    stats.totalAccounts > 0
                        ? `${stats.totalAccounts} channel(s) connected`
                        : "Connect channels from their own pages",
                done: stats.totalAccounts > 0,
            },
            {
                title: "Content pipeline",
                text:
                    stats.pendingWork > 0
                        ? `${stats.pendingWork} item(s) waiting or processing`
                        : "No pending content right now",
                done: stats.pendingWork > 0,
            },
            {
                title: "WhatsApp templates",
                text:
                    stats.approvedTemplates > 0
                        ? `${stats.approvedTemplates} approved template(s)`
                        : "Create or sync templates from WhatsApp page",
                done: stats.approvedTemplates > 0,
            },
            {
                title: "System health",
                text:
                    stats.failedWork > 0
                        ? `${stats.failedWork} failed item(s) need attention`
                        : "No failed items found",
                done: stats.failedWork === 0,
                danger: stats.failedWork > 0,
            },
        ];
    }, [stats]);

    if (loading) {
        return (
            <div className="flex min-h-[65vh] items-center justify-center">
                <div className="retro-card flex items-center gap-4 bg-white px-6 py-5">
                    <Loader2 className="h-6 w-6 animate-spin text-[var(--retro-ink)]" />
                    <span className="font-mono text-xs font-black uppercase tracking-[0.18em] text-[var(--retro-ink)]">
                        Loading dashboard
                    </span>
                </div>
            </div>
        );
    }

    return (
        <motion.div
            initial={{ opacity: 0, x: 16 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -16 }}
            className="space-y-8"
        >
            <div className="retro-card relative overflow-hidden bg-[var(--retro-blue-soft)] p-5 md:p-7">
                <div className="absolute right-0 top-0 h-16 w-16 border-b-2 border-l-2 border-[var(--retro-line)] bg-[var(--retro-cyan)]" />
                <div className="absolute bottom-0 left-0 h-12 w-12 border-r-2 border-t-2 border-[var(--retro-line)] bg-[var(--retro-lime)]" />

                <div className="relative z-10 flex flex-col justify-between gap-6 xl:flex-row xl:items-end">
                    <div className="max-w-3xl">
                        <div className="mb-4 flex flex-wrap items-center gap-3">
                            <span className="retro-badge retro-badge-magenta px-3 py-2">Unified Overview</span>
                            <span className="retro-badge retro-badge-yellow px-3 py-2">System Console</span>
                        </div>

                        <h1 className="retro-heading text-4xl md:text-5xl">
                            Welcome back, {user?.firstName || "User"}!
                        </h1>

                        <p className="mt-4 max-w-2xl text-base font-semibold leading-7 text-slate-700">
                            This dashboard shows combined publishing and messaging activity. Platform account actions
                            stay inside their own dedicated pages.
                        </p>
                    </div>

                    <div className="grid gap-3 sm:grid-cols-3 xl:min-w-[520px]">
                        <button
                            onClick={() => router.push("/publishing")}
                            className="retro-button flex items-center justify-center gap-2 px-4 py-3 text-sm"
                        >
                            <CalendarClock className="h-5 w-5" />
                            Publishing
                        </button>

                        <button
                            onClick={() => router.push("/whatsapp")}
                            className="retro-button-secondary flex items-center justify-center gap-2 bg-[var(--retro-lime)] px-4 py-3 text-sm"
                        >
                            <MessageCircle className="h-5 w-5" />
                            WhatsApp
                        </button>

                        <button
                            onClick={loadDashboard}
                            disabled={refreshing}
                            className="retro-button-secondary flex items-center justify-center gap-2 px-4 py-3 text-sm disabled:opacity-60"
                        >
                            {refreshing ? (
                                <Loader2 className="h-5 w-5 animate-spin" />
                            ) : (
                                <RefreshCw className="h-5 w-5" />
                            )}
                            Refresh
                        </button>
                    </div>
                </div>
            </div>

            {notice && (
                <div
                    className={`retro-card flex items-center gap-3 px-4 py-3 ${
                        notice.type === "success" ? "bg-[var(--retro-mint)]" : "bg-[#ffe4e9]"
                    }`}
                >
                    {notice.type === "success" ? (
                        <CheckCircle2 className="h-5 w-5" />
                    ) : (
                        <AlertTriangle className="h-5 w-5" />
                    )}
                    <span className="text-sm font-black text-[var(--retro-ink)]">{notice.message}</span>
                </div>
            )}

            <div className="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-4">
                <MetricCard
                    title="Connected Channels"
                    value={stats.totalAccounts}
                    text={`${stats.twitterAccounts} Twitter, ${stats.mastodonAccounts} Mastodon, ${stats.threadsAccounts} Threads, ${stats.whatsAppNumbers} WhatsApp`}
                    icon={Share2}
                    accent="cyan"
                />

                <MetricCard
                    title="Pending Work"
                    value={stats.pendingWork}
                    text="Queued posts and WhatsApp messages"
                    icon={Clock}
                    accent="yellow"
                />

                <MetricCard
                    title="Completed"
                    value={stats.completedWork}
                    text="Posted content and sent messages"
                    icon={CheckCircle2}
                    accent="lime"
                />

                <MetricCard
                    title="Needs Attention"
                    value={stats.failedWork}
                    text="Failed posts or failed WhatsApp sends"
                    icon={stats.failedWork > 0 ? AlertTriangle : Sparkles}
                    accent={stats.failedWork > 0 ? "red" : "magenta"}
                />
            </div>

            <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
                <div className="retro-card overflow-hidden bg-white/85 xl:col-span-2">
                    <SectionHeader
                        title="Combined Activity"
                        text="Recent scheduled, sent, queued, and failed content from all supported channels."
                        code="ACTIVITY.LOG"
                    />

                    <div className="divide-y-2 divide-[var(--retro-line)]">
                        {activityItems.length === 0 ? (
                            <EmptyState
                                title="No activity yet"
                                text="Create a social post or send a WhatsApp template message to see activity here."
                            />
                        ) : (
                            activityItems.map((item) => (
                                <div
                                    key={item.id}
                                    className="group grid gap-4 bg-white/70 p-5 transition-all duration-200 hover:bg-[var(--retro-blue-soft)] lg:grid-cols-[1fr_auto]"
                                >
                                    <div className="flex items-start gap-4">
                                        <div
                                            className={`flex h-12 w-12 shrink-0 items-center justify-center border-2 border-[var(--retro-line)] shadow-[3px_3px_0px_0px_var(--retro-line)] ${
                                                item.type === "whatsapp"
                                                    ? "bg-[var(--retro-lime)]"
                                                    : "bg-[var(--retro-cyan)]"
                                            }`}
                                        >
                                            {item.type === "whatsapp" ? (
                                                <MessageCircle className="h-5 w-5 text-[var(--retro-ink)]" />
                                            ) : (
                                                <Share2 className="h-5 w-5 text-[var(--retro-ink)]" />
                                            )}
                                        </div>

                                        <div className="min-w-0">
                                            <h3 className="text-base font-black tracking-[-0.03em] text-[var(--retro-ink)]">
                                                {item.title}
                                            </h3>
                                            <p className="mt-1 line-clamp-2 text-sm font-semibold leading-6 text-slate-600">
                                                {item.subtitle}
                                            </p>
                                            <p className="mt-2 font-mono text-[11px] font-black uppercase tracking-[0.14em] text-slate-500">
                                                {item.time}
                                            </p>
                                        </div>
                                    </div>

                                    <div className="flex items-center lg:justify-end">
                                        <span
                                            className={`border-2 border-[var(--retro-line)] px-3 py-2 font-mono text-[10px] font-black uppercase tracking-[0.14em] shadow-[2px_2px_0px_0px_var(--retro-line)] ${getStatusClass(item.status)}`}
                                        >
                                            {item.status}
                                        </span>
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </div>

                <div className="retro-card overflow-hidden bg-white/85">
                    <SectionHeader
                        title="System Readiness"
                        text="High-level setup and health checks."
                        code="READY.CHECK"
                    />

                    <div className="space-y-4 p-5">
                        {readiness.map((item) => (
                            <div
                                key={item.title}
                                className={`border-2 border-[var(--retro-line)] p-4 shadow-[4px_4px_0px_0px_var(--retro-line)] ${
                                    item.danger
                                        ? "bg-[#ffe4e9]"
                                        : item.done
                                          ? "bg-[var(--retro-mint)]"
                                          : "bg-[var(--retro-yellow)]"
                                }`}
                            >
                                <div className="flex items-start gap-3">
                                    <div className="flex h-10 w-10 shrink-0 items-center justify-center border-2 border-[var(--retro-line)] bg-white">
                                        {item.danger ? (
                                            <AlertTriangle className="h-5 w-5 text-[var(--retro-ink)]" />
                                        ) : item.done ? (
                                            <CheckCircle2 className="h-5 w-5 text-[var(--retro-ink)]" />
                                        ) : (
                                            <Clock className="h-5 w-5 text-[var(--retro-ink)]" />
                                        )}
                                    </div>

                                    <div>
                                        <h3 className="text-sm font-black tracking-[-0.02em] text-[var(--retro-ink)]">
                                            {item.title}
                                        </h3>
                                        <p className="mt-1 text-sm font-semibold leading-6 text-slate-700">
                                            {item.text}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 gap-5 xl:grid-cols-5">
                <QuickAction
                    title="Publishing Hub"
                    text="Compose and schedule social content"
                    icon={CalendarClock}
                    onClick={() => router.push("/publishing")}
                    accent="cyan"
                />

                <QuickAction
                    title="Twitter / X"
                    text="Manage Twitter connection and posts"
                    icon={Share2}
                    onClick={() => router.push("/twitter")}
                    accent="ink"
                />

                <QuickAction
                    title="Mastodon"
                    text="Manage Mastodon connection and posts"
                    icon={Users}
                    onClick={() => router.push("/mastodon")}
                    accent="magenta"
                />

                <QuickAction
                    title="Instagram Threads"
                    text="Manage Threads connection and posts"
                    icon={Share2}
                    onClick={() => router.push("/threads")}
                    accent="yellow"
                />

                <QuickAction
                    title="WhatsApp"
                    text="Send, schedule, and monitor messages"
                    icon={MessageCircle}
                    onClick={() => router.push("/whatsapp")}
                    accent="lime"
                />
            </div>

            <div className="retro-card bg-[var(--retro-pink-soft)] p-5">
                <div className="flex items-start gap-4">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center border-2 border-[var(--retro-line)] bg-[var(--retro-magenta)] shadow-[3px_3px_0px_0px_var(--retro-line)]">
                        <BarChart3 className="h-6 w-6 text-white" />
                    </div>

                    <div>
                        <div className="mb-2 flex flex-wrap items-center gap-2">
                            <span className="retro-badge retro-badge-cyan px-3 py-2">Dashboard Rule</span>
                            <span className="retro-badge px-3 py-2">Combined Data Only</span>
                        </div>

                        <h3 className="text-xl font-black tracking-[-0.05em] text-[var(--retro-ink)]">
                            Main dashboard stays clean and focused.
                        </h3>

                        <p className="mt-2 max-w-4xl text-sm font-semibold leading-6 text-slate-700">
                            This page is only for combined system content and overall health. Twitter, Mastodon,
                            Threads, and WhatsApp account actions stay inside their own pages.
                        </p>
                    </div>
                </div>
            </div>
        </motion.div>
    );
}

function MetricCard({
    title,
    value,
    text,
    icon: Icon,
    accent,
}: {
    title: string;
    value: number;
    text: string;
    icon: LucideIcon;
    accent: "cyan" | "lime" | "yellow" | "magenta" | "red";
}) {
    const accentClass = {
        cyan: "bg-[var(--retro-cyan)]",
        lime: "bg-[var(--retro-lime)]",
        yellow: "bg-[var(--retro-yellow)]",
        magenta: "bg-[var(--retro-magenta)] text-white",
        red: "bg-[#ff4d6d] text-white",
    }[accent];

    return (
        <div className="retro-card group relative overflow-hidden bg-white/85 p-5">
            <div
                className={`absolute right-0 top-0 h-4 w-16 border-b-2 border-l-2 border-[var(--retro-line)] ${accentClass}`}
            />

            <div className="flex items-start justify-between gap-4">
                <div className="min-w-0">
                    <p className="retro-label">{title}</p>
                    <h3 className="mt-3 text-4xl font-black tracking-[-0.08em] text-[var(--retro-ink)]">{value}</h3>
                    <p className="mt-2 text-sm font-semibold leading-6 text-slate-600">{text}</p>
                </div>

                <div
                    className={`flex h-12 w-12 shrink-0 items-center justify-center border-2 border-[var(--retro-line)] shadow-[3px_3px_0px_0px_var(--retro-line)] transition-all duration-200 group-hover:-translate-x-1 group-hover:-translate-y-1 group-hover:shadow-[5px_5px_0px_0px_var(--retro-line)] ${accentClass}`}
                >
                    <Icon className="h-6 w-6" />
                </div>
            </div>
        </div>
    );
}

function SectionHeader({ title, text, code }: { title: string; text: string; code: string }) {
    return (
        <div className="border-b-2 border-[var(--retro-line)] bg-[var(--retro-yellow)] p-5">
            <div className="mb-3 flex items-center justify-between gap-3">
                <span className="font-mono text-[10px] font-black uppercase tracking-[0.18em] text-[var(--retro-muted)]">
                    {code}
                </span>

                <span className="h-3 w-3 border-2 border-[var(--retro-line)] bg-[var(--retro-magenta)]" />
            </div>

            <h2 className="text-2xl font-black tracking-[-0.06em] text-[var(--retro-ink)]">{title}</h2>
            <p className="mt-1 text-sm font-semibold leading-6 text-slate-700">{text}</p>
        </div>
    );
}

function EmptyState({ title, text }: { title: string; text: string }) {
    return (
        <div className="p-8 text-center">
            <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center border-2 border-[var(--retro-line)] bg-[var(--retro-blue-soft)] shadow-[4px_4px_0px_0px_var(--retro-line)]">
                <FileText className="h-6 w-6 text-[var(--retro-ink)]" />
            </div>

            <h3 className="text-lg font-black tracking-[-0.04em] text-[var(--retro-ink)]">{title}</h3>
            <p className="mt-2 text-sm font-semibold text-slate-600">{text}</p>
        </div>
    );
}

function QuickAction({
    title,
    text,
    icon: Icon,
    onClick,
    accent,
}: {
    title: string;
    text: string;
    icon: LucideIcon;
    onClick: () => void;
    accent: "cyan" | "lime" | "yellow" | "magenta" | "ink";
}) {
    const accentClass = {
        cyan: "bg-[var(--retro-cyan)]",
        lime: "bg-[var(--retro-lime)]",
        yellow: "bg-[var(--retro-yellow)]",
        magenta: "bg-[var(--retro-magenta)] text-white",
        ink: "bg-[var(--retro-ink)] text-white",
    }[accent];

    return (
        <button onClick={onClick} className="retro-card group text-left bg-white/85 p-5">
            <div
                className={`mb-5 flex h-12 w-12 items-center justify-center border-2 border-[var(--retro-line)] shadow-[3px_3px_0px_0px_var(--retro-line)] transition-all duration-200 group-hover:-translate-x-1 group-hover:-translate-y-1 group-hover:shadow-[5px_5px_0px_0px_var(--retro-line)] ${accentClass}`}
            >
                <Icon className="h-6 w-6" />
            </div>

            <h3 className="text-base font-black tracking-[-0.04em] text-[var(--retro-ink)]">{title}</h3>
            <p className="mt-2 text-sm font-semibold leading-6 text-slate-600">{text}</p>

            <div className="mt-5 flex items-center gap-2 font-mono text-[10px] font-black uppercase tracking-[0.16em] text-[var(--retro-muted)]">
                <Zap className="h-3.5 w-3.5" />
                <span>Quick Launch</span>
            </div>
        </button>
    );
}
