"use client"

import Sidebar from "@/components/Sidebar"
import Navbar from "@/components/Navbar"
import { AnimatePresence, motion } from "framer-motion"
import { usePathname } from "next/navigation"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const pathname = usePathname()

  return (
    <div className="relative flex min-h-screen overflow-hidden bg-transparent text-[var(--retro-ink)]">
      <div className="pointer-events-none fixed left-0 top-0 z-0 h-16 w-16 border-b-2 border-r-2 border-[var(--retro-line)] bg-[var(--retro-cyan)] opacity-70" />
      <div className="pointer-events-none fixed right-0 top-0 z-0 h-16 w-16 border-b-2 border-l-2 border-[var(--retro-line)] bg-[var(--retro-magenta)] opacity-60" />
      <div className="pointer-events-none fixed bottom-0 left-0 z-0 h-16 w-16 border-r-2 border-t-2 border-[var(--retro-line)] bg-[var(--retro-lime)] opacity-60" />
      <div className="pointer-events-none fixed bottom-0 right-0 z-0 h-16 w-16 border-l-2 border-t-2 border-[var(--retro-line)] bg-[var(--retro-yellow)] opacity-70" />

      <Sidebar />

      <div className="relative z-10 flex h-screen min-w-0 flex-1 flex-col">
        <Navbar />

        <AnimatePresence mode="wait">
          <motion.main
            key={pathname}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.22, ease: "easeOut" }}
            className="custom-scrollbar flex-1 overflow-y-auto p-4 md:p-6 lg:p-8"
          >
            <div className="mx-auto max-w-7xl">
              <div className="retro-shell relative min-h-[calc(100vh-8rem)] bg-white/80 p-4 md:p-6 lg:p-8">
                <div className="pointer-events-none absolute left-0 top-0 h-3 w-3 border-b-2 border-r-2 border-[var(--retro-line)] bg-[var(--retro-cyan)]" />
                <div className="pointer-events-none absolute right-0 top-0 h-3 w-3 border-b-2 border-l-2 border-[var(--retro-line)] bg-[var(--retro-magenta)]" />
                <div className="pointer-events-none absolute bottom-0 left-0 h-3 w-3 border-r-2 border-t-2 border-[var(--retro-line)] bg-[var(--retro-lime)]" />
                <div className="pointer-events-none absolute bottom-0 right-0 h-3 w-3 border-l-2 border-t-2 border-[var(--retro-line)] bg-[var(--retro-yellow)]" />

                {children}
              </div>
            </div>
          </motion.main>
        </AnimatePresence>
      </div>
    </div>
  )
}