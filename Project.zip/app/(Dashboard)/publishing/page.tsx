"use client";

import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
    AlertTriangle,
    Calendar,
    CheckCircle2,
    Clock,
    SlidersHorizontal,
    X,
    List,
    Loader2,
    Plus,
    RotateCcw,
    Search,
    Send,
    Trash2,
} from "lucide-react";
import ComposeModal from "@/app/(Dashboard)/publishing/ComposeModal";
import PublishingCalendar from "@/app/(Dashboard)/publishing/PublishingCalendar";
import { PLATFORMS } from "@/libs/platform";

type Post = {
    id: string;
    content: string;
    status: "pending" | "processing" | "posted" | "failed";
    scheduledAt: string | null;
    postedAt: string | null;
    createdAt: string;
    socialAccount: {
        id: string;
        platform: keyof typeof PLATFORMS;
        accountUsername: string;
    };
};

type StatusFilter = "all" | "pending" | "processing" | "posted" | "failed";
type PlatformFilter = "all" | "twitter" | "mastodon" | "threads";
type TypeFilter = "all" | "scheduled" | "immediate";

const platformOptions: { label: string; value: PlatformFilter }[] = [
    { label: "All", value: "all" },
    { label: "Twitter / X", value: "twitter" },
    { label: "Mastodon", value: "mastodon" },
    { label: "Threads", value: "threads" },
];

const statusOptions: { label: string; value: StatusFilter }[] = [
    { label: "All", value: "all" },
    { label: "Pending", value: "pending" },
    { label: "Processing", value: "processing" },
    { label: "Posted", value: "posted" },
    { label: "Failed", value: "failed" },
];

const typeOptions: { label: string; value: TypeFilter }[] = [
    { label: "All", value: "all" },
    { label: "Scheduled", value: "scheduled" },
    { label: "Immediate / Posted", value: "immediate" },
];

const filterChipClass = (active: boolean) => {
    return `px-4 py-2 rounded-xl text-sm font-semibold border transition-all ${
        active
            ? "bg-purple-600 text-white border-purple-400/40 shadow-lg shadow-purple-600/20"
            : "bg-gray-950/60 text-gray-400 border-white/10 hover:text-white hover:bg-white/10"
    }`;
};

const getPostTime = (post: Post) => {
    return post.postedAt || post.scheduledAt || post.createdAt;
};

const getStatusClass = (status: Post["status"]) => {
    if (status === "posted") return "bg-emerald-500/10 text-emerald-400";
    if (status === "pending") return "bg-amber-500/10 text-amber-400";
    if (status === "processing") return "bg-purple-500/10 text-purple-300";
    return "bg-red-500/10 text-red-400";
};

export default function PublishingPage() {
    const [view, setView] = useState<"list" | "calendar">("list");
    const [isComposeOpen, setIsComposeOpen] = useState(false);
    const [selectedAccounts, setSelectedAccounts] = useState<string[]>([]);
    const [posts, setPosts] = useState<Post[]>([]);
    const [loadingPosts, setLoadingPosts] = useState(true);
    const [deletingPostId, setDeletingPostId] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [searchQuery, setSearchQuery] = useState("");
    const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
    const [platformFilter, setPlatformFilter] = useState<PlatformFilter>("all");
    const [typeFilter, setTypeFilter] = useState<TypeFilter>("all");

    const loadPosts = async () => {
        try {
            setLoadingPosts(true);
            setError(null);

            const res = await fetch("/api/posts");

            if (!res.ok) {
                throw new Error("Failed to load posts");
            }

            const data = await res.json();
            setPosts(data.posts || []);
        } catch (error) {
            setError(error instanceof Error ? error.message : "Something went wrong");
        } finally {
            setLoadingPosts(false);
        }
    };

    useEffect(() => {
        loadPosts();
    }, []);

    const closeCompose = () => {
        setIsComposeOpen(false);
        setSelectedAccounts([]);
        loadPosts();
    };

    const filteredPosts = useMemo(() => {
        const normalizedSearch = searchQuery.trim().toLowerCase();

        return posts.filter((post) => {
            const platform = post.socialAccount.platform;
            const platformName = PLATFORMS[platform]?.name || platform;

            const matchesSearch =
                !normalizedSearch ||
                post.content.toLowerCase().includes(normalizedSearch) ||
                post.socialAccount.accountUsername.toLowerCase().includes(normalizedSearch) ||
                platformName.toLowerCase().includes(normalizedSearch) ||
                post.status.toLowerCase().includes(normalizedSearch);

            const matchesStatus = statusFilter === "all" || post.status === statusFilter;
            const matchesPlatform = platformFilter === "all" || platform === platformFilter;

            const matchesType =
                typeFilter === "all" ||
                (typeFilter === "scheduled" && Boolean(post.scheduledAt) && post.status !== "posted") ||
                (typeFilter === "immediate" && (!post.scheduledAt || post.status === "posted"));

            return matchesSearch && matchesStatus && matchesPlatform && matchesType;
        });
    }, [posts, searchQuery, statusFilter, platformFilter, typeFilter]);

    const hasActiveFilters =
        searchQuery.trim().length > 0 || statusFilter !== "all" || platformFilter !== "all" || typeFilter !== "all";

    const clearFilters = () => {
        setSearchQuery("");
        setStatusFilter("all");
        setPlatformFilter("all");
        setTypeFilter("all");
    };

    const deletePost = async (post: Post) => {
        if (post.status === "processing") {
            setError("This post is currently being processed and cannot be deleted.");
            return;
        }

        const message =
            post.status === "posted"
                ? "This will remove the post from your app history only. It will not delete it from the social platform. Continue?"
                : "Delete this scheduled post? This action cannot be undone.";

        const confirmed = window.confirm(message);

        if (!confirmed) return;

        try {
            setDeletingPostId(post.id);
            setError(null);

            const res = await fetch(`/api/posts/${post.id}`, {
                method: "DELETE",
            });

            const data = await res.json().catch(() => ({}));

            if (!res.ok) {
                throw new Error(data.error || "Failed to delete post");
            }

            setPosts((current) => current.filter((item) => item.id !== post.id));
        } catch (error) {
            setError(error instanceof Error ? error.message : "Failed to delete post");
        } finally {
            setDeletingPostId(null);
        }
    };

    const totalPosts = posts.length;
    const pendingPosts = posts.filter((post) => post.status === "pending").length;
    const postedPosts = posts.filter((post) => post.status === "posted").length;
    const failedPosts = posts.filter((post) => post.status === "failed").length;

    return (
        <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-6"
        >
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-5">
                <div>
                    <h1 className="text-3xl font-bold text-white">Publishing</h1>
                    <p className="text-gray-400 mt-1">
                        Create, schedule, search, filter, and manage Twitter/X, Mastodon, and Instagram Threads posts.
                    </p>
                </div>

                <div className="flex items-center gap-3">
                    <div className="flex p-1 bg-gray-900/50 rounded-xl border border-white/5">
                        <button
                            type="button"
                            onClick={() => setView("list")}
                            className={`p-2 rounded-lg transition-all ${
                                view === "list"
                                    ? "bg-purple-600 text-white shadow-md"
                                    : "text-gray-500 hover:text-white"
                            }`}
                        >
                            <List className="w-4 h-4" />
                        </button>

                        <button
                            type="button"
                            onClick={() => setView("calendar")}
                            className={`p-2 rounded-lg transition-all ${
                                view === "calendar"
                                    ? "bg-purple-600 text-white shadow-md"
                                    : "text-gray-500 hover:text-white"
                            }`}
                        >
                            <Calendar className="w-4 h-4" />
                        </button>
                    </div>

                    <button
                        type="button"
                        onClick={() => setIsComposeOpen(true)}
                        className="flex items-center gap-2 bg-purple-600 hover:bg-purple-500 text-white px-5 py-2.5 rounded-xl font-bold shadow-lg shadow-purple-600/20 active:scale-95 transition-all"
                    >
                        <Plus className="w-5 h-5" />
                        Compose
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="glass rounded-2xl border border-white/5 p-5">
                    <p className="text-sm text-gray-400">Total Posts</p>
                    <h3 className="text-2xl font-bold text-white mt-2">{totalPosts}</h3>
                </div>

                <div className="glass rounded-2xl border border-white/5 p-5">
                    <p className="text-sm text-gray-400">Pending</p>
                    <h3 className="text-2xl font-bold text-amber-300 mt-2">{pendingPosts}</h3>
                </div>

                <div className="glass rounded-2xl border border-white/5 p-5">
                    <p className="text-sm text-gray-400">Posted</p>
                    <h3 className="text-2xl font-bold text-emerald-300 mt-2">{postedPosts}</h3>
                </div>

                <div className="glass rounded-2xl border border-white/5 p-5">
                    <p className="text-sm text-gray-400">Failed</p>
                    <h3 className="text-2xl font-bold text-red-300 mt-2">{failedPosts}</h3>
                </div>
            </div>

            <div className="glass rounded-2xl border border-white/5 overflow-hidden">
                <div className="p-6 border-b border-white/5 bg-gradient-to-br from-white/[0.07] via-white/[0.03] to-purple-950/20 space-y-6">
                    <div className="flex flex-col xl:flex-row xl:items-start xl:justify-between gap-5">
                        <div>
                            <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-2xl bg-purple-600/20 border border-purple-500/30 flex items-center justify-center">
                                    <SlidersHorizontal className="w-5 h-5 text-purple-300" />
                                </div>

                                <div>
                                    <h3 className="font-bold text-white">
                                        {view === "list" ? "Publishing Table" : "Publishing Calendar"}
                                    </h3>

                                    <p className="text-sm text-gray-500 mt-1">
                                        Showing {filteredPosts.length} of {posts.length} posts.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div className="flex items-center gap-3">
                            {hasActiveFilters && (
                                <button
                                    type="button"
                                    onClick={clearFilters}
                                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-300 text-sm font-semibold transition"
                                >
                                    <RotateCcw className="w-4 h-4" />
                                    Clear Filters
                                </button>
                            )}

                            <button
                                type="button"
                                onClick={loadPosts}
                                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-gray-300 text-sm font-semibold transition"
                            >
                                <RotateCcw className="w-4 h-4" />
                                Refresh
                            </button>
                        </div>
                    </div>

                    <div className="relative">
                        <Search className="w-5 h-5 text-gray-500 absolute left-4 top-1/2 -translate-y-1/2" />

                        <input
                            value={searchQuery}
                            onChange={(event) => setSearchQuery(event.target.value)}
                            placeholder="Search by content, username, platform, or status..."
                            className="w-full bg-gray-950/80 border border-white/10 rounded-2xl pl-12 pr-12 py-4 text-sm text-white placeholder:text-gray-600 focus:outline-none focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition"
                        />

                        {searchQuery && (
                            <button
                                type="button"
                                onClick={() => setSearchQuery("")}
                                className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white transition"
                            >
                                <X className="w-5 h-5" />
                            </button>
                        )}
                    </div>

                    <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
                        <div className="rounded-2xl bg-gray-950/50 border border-white/10 p-4">
                            <div className="flex items-center justify-between mb-4">
                                <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">Platform</p>

                                <span className="text-[11px] text-gray-600">Channel</span>
                            </div>

                            <div className="flex flex-wrap gap-2">
                                {platformOptions.map((option) => {
                                    const platformInfo = option.value !== "all" ? PLATFORMS[option.value] : null;
                                    const Icon = platformInfo?.icon || SlidersHorizontal;

                                    return (
                                        <button
                                            key={option.value}
                                            type="button"
                                            onClick={() => setPlatformFilter(option.value)}
                                            className={filterChipClass(platformFilter === option.value)}
                                        >
                                            <span className="flex items-center gap-2">
                                                <Icon className={`w-4 h-4 ${platformInfo?.color || ""}`} />
                                                {option.label}
                                            </span>
                                        </button>
                                    );
                                })}
                            </div>
                        </div>

                        <div className="rounded-2xl bg-gray-950/50 border border-white/10 p-4">
                            <div className="flex items-center justify-between mb-4">
                                <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">Status</p>

                                <span className="text-[11px] text-gray-600">Progress</span>
                            </div>

                            <div className="flex flex-wrap gap-2">
                                {statusOptions.map((option) => (
                                    <button
                                        key={option.value}
                                        type="button"
                                        onClick={() => setStatusFilter(option.value)}
                                        className={filterChipClass(statusFilter === option.value)}
                                    >
                                        {option.label}
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div className="rounded-2xl bg-gray-950/50 border border-white/10 p-4">
                            <div className="flex items-center justify-between mb-4">
                                <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">Post Type</p>

                                <span className="text-[11px] text-gray-600">Timing</span>
                            </div>

                            <div className="flex flex-wrap gap-2">
                                {typeOptions.map((option) => (
                                    <button
                                        key={option.value}
                                        type="button"
                                        onClick={() => setTypeFilter(option.value)}
                                        className={filterChipClass(typeFilter === option.value)}
                                    >
                                        {option.label}
                                    </button>
                                ))}
                            </div>
                        </div>
                    </div>

                    {hasActiveFilters && (
                        <div className="flex flex-wrap items-center gap-2 pt-1">
                            <span className="text-xs text-gray-500 font-semibold">Active filters:</span>

                            {searchQuery.trim() && (
                                <span className="px-3 py-1.5 rounded-lg bg-purple-500/10 border border-purple-500/20 text-purple-200 text-xs font-semibold">
                                    Search: {searchQuery}
                                </span>
                            )}

                            {platformFilter !== "all" && (
                                <span className="px-3 py-1.5 rounded-lg bg-purple-500/10 border border-purple-500/20 text-purple-200 text-xs font-semibold">
                                    Platform: {PLATFORMS[platformFilter]?.name || platformFilter}
                                </span>
                            )}

                            {statusFilter !== "all" && (
                                <span className="px-3 py-1.5 rounded-lg bg-purple-500/10 border border-purple-500/20 text-purple-200 text-xs font-semibold">
                                    Status: {statusFilter}
                                </span>
                            )}

                            {typeFilter !== "all" && (
                                <span className="px-3 py-1.5 rounded-lg bg-purple-500/10 border border-purple-500/20 text-purple-200 text-xs font-semibold">
                                    Type: {typeFilter === "scheduled" ? "Scheduled" : "Immediate / Posted"}
                                </span>
                            )}
                        </div>
                    )}
                </div>

                {error && (
                    <div className="m-6 rounded-2xl bg-red-500/10 border border-red-500/20 p-4 flex items-start gap-3 text-red-200">
                        <AlertTriangle className="w-5 h-5 mt-0.5" />
                        <p className="text-sm font-semibold">{error}</p>
                    </div>
                )}

                {loadingPosts ? (
                    <div className="p-14 flex justify-center">
                        <Loader2 className="w-7 h-7 animate-spin text-purple-400" />
                    </div>
                ) : posts.length === 0 ? (
                    <div className="p-14 text-center">
                        <div className="w-14 h-14 mx-auto rounded-2xl bg-purple-600/10 border border-purple-500/20 flex items-center justify-center">
                            <Send className="w-7 h-7 text-purple-300" />
                        </div>
                        <h3 className="text-white font-bold mt-5">No posts yet</h3>
                        <p className="text-gray-400 text-sm mt-2">
                            Compose your first Twitter/X, Mastodon, or Instagram Threads post.
                        </p>
                    </div>
                ) : filteredPosts.length === 0 ? (
                    <div className="p-14 text-center">
                        <div className="w-14 h-14 mx-auto rounded-2xl bg-white/5 border border-white/5 flex items-center justify-center">
                            <Search className="w-7 h-7 text-gray-400" />
                        </div>
                        <h3 className="text-white font-bold mt-5">No matching posts</h3>
                        <p className="text-gray-400 text-sm mt-2">Change your search or filters.</p>
                    </div>
                ) : view === "calendar" ? (
                    <PublishingCalendar
                        posts={filteredPosts}
                        onCompose={() => setIsComposeOpen(true)}
                        onDelete={deletePost}
                        deletingPostId={deletingPostId}
                    />
                ) : (
                    <div className="overflow-x-auto">
                        <table className="w-full min-w-[980px]">
                            <thead className="bg-gray-950/50 border-b border-white/5">
                                <tr>
                                    <th className="text-left px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-widest">
                                        Account
                                    </th>
                                    <th className="text-left px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-widest">
                                        Content
                                    </th>
                                    <th className="text-left px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-widest">
                                        Time
                                    </th>
                                    <th className="text-left px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-widest">
                                        Status
                                    </th>
                                    <th className="text-right px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-widest">
                                        Actions
                                    </th>
                                </tr>
                            </thead>

                            <tbody className="divide-y divide-white/5">
                                {filteredPosts.map((post, index) => {
                                    const platform = PLATFORMS[post.socialAccount.platform];
                                    const Icon = platform?.icon || Send;
                                    const postTime = getPostTime(post);
                                    const isDeleting = deletingPostId === post.id;

                                    return (
                                        <motion.tr
                                            key={post.id}
                                            initial={{ opacity: 0, y: 8 }}
                                            animate={{ opacity: 1, y: 0 }}
                                            transition={{ delay: index * 0.02 }}
                                            className="hover:bg-white/[0.03] transition-colors"
                                        >
                                            <td className="px-6 py-5 align-top">
                                                <div className="flex items-center gap-3">
                                                    <div className="p-2.5 rounded-xl bg-gray-900 border border-white/5">
                                                        <Icon
                                                            className={`w-5 h-5 ${platform?.color || "text-purple-300"}`}
                                                        />
                                                    </div>

                                                    <div>
                                                        <h4 className="font-bold text-white">
                                                            @{post.socialAccount.accountUsername}
                                                        </h4>
                                                        <p className="text-xs text-gray-500 mt-1">
                                                            {platform?.name || post.socialAccount.platform}
                                                        </p>
                                                    </div>
                                                </div>
                                            </td>

                                            <td className="px-6 py-5 align-top max-w-md">
                                                <p className="text-sm text-gray-300 leading-relaxed line-clamp-3">
                                                    {post.content}
                                                </p>
                                            </td>

                                            <td className="px-6 py-5 align-top">
                                                <div className="flex items-start gap-2 text-sm text-gray-400">
                                                    <Clock className="w-4 h-4 mt-0.5 text-gray-500" />
                                                    <div>
                                                        <p>
                                                            {post.status === "posted"
                                                                ? "Posted"
                                                                : post.scheduledAt
                                                                  ? "Scheduled"
                                                                  : "Queued"}
                                                        </p>
                                                        <p className="text-xs text-gray-500 mt-1">
                                                            {new Date(postTime).toLocaleString()}
                                                        </p>

                                                        {!post.scheduledAt && post.status === "pending" && (
                                                            <span className="inline-flex items-center gap-1 text-emerald-300 text-xs mt-2">
                                                                <CheckCircle2 className="w-3 h-3" />
                                                                Immediate
                                                            </span>
                                                        )}
                                                    </div>
                                                </div>
                                            </td>

                                            <td className="px-6 py-5 align-top">
                                                <span
                                                    className={`px-3 py-1 rounded-lg text-[10px] font-bold uppercase tracking-widest ${getStatusClass(post.status)}`}
                                                >
                                                    {post.status}
                                                </span>
                                            </td>

                                            <td className="px-6 py-5 align-top text-right">
                                                <button
                                                    type="button"
                                                    onClick={() => deletePost(post)}
                                                    disabled={isDeleting || post.status === "processing"}
                                                    className="inline-flex items-center justify-center gap-2 px-3 py-2 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-300 text-xs font-bold transition disabled:opacity-50 disabled:cursor-not-allowed"
                                                >
                                                    {isDeleting ? (
                                                        <Loader2 className="w-4 h-4 animate-spin" />
                                                    ) : (
                                                        <Trash2 className="w-4 h-4" />
                                                    )}
                                                    Delete
                                                </button>
                                            </td>
                                        </motion.tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>

            <ComposeModal
                selectedAccounts={selectedAccounts}
                setSelectedAccounts={setSelectedAccounts}
                isOpen={isComposeOpen}
                onClose={closeCompose}
            />
        </motion.div>
    );
}
